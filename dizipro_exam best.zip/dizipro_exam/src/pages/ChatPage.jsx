import React from 'react'
import Header2 from '../components/Header2'
import Chat from '../components/Chat'
import Footer from '../components/Footer'
function ChatPage() {
  return (
    <div>
        <Header2 />
        <Chat />
        <Footer />
    </div>
  )
}

export default ChatPage