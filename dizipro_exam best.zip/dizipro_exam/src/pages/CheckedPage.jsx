import React from 'react'
import Checked from '../components/Checked'

function CheckedPage() {
  return (
    <div>
      <Checked />
    </div>
  )
}

export default CheckedPage