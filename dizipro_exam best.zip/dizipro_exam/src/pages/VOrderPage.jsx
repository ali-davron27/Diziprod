import React from 'react'
import Header from '../components/Header' 
import Veiw from '../pages/View oreder/VeiwOrder'
import Footer from '../components/Footer'

function VOrderPage() {
  return (
    <div>
      <Header />
      <Veiw />
      <Footer />
    </div>
  )
}

export default VOrderPage