import React from 'react'
import Signup from '../components/SignUp'

function SignupPage() {
  return (
    <div>
      <Signup />
    </div>
  )
}

export default SignupPage