import React from 'react'
import Header2 from '../components/Header2'
import Profile from '../components/Profile'
import Footer from '../components/Footer'
function ProfilePage() {
  return (
    <div>
        <Header2 />
        <Profile />
        <Footer />
    </div>
  )
}

export default ProfilePage





