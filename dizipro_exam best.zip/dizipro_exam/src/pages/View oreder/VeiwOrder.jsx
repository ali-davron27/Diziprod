import React from 'react';
import '/home/kali/Desktop/react/dizipro_exam/src/styles/View-style/View-order.css';
import {Link} from 'react-router-dom'
import Order1 from'../View oreder/order images/Rectangle 445.png';
import Order2 from'../View oreder/order images/Rectangle 441.png';
import Order3 from'../View oreder/order images/Rectangle 439.png';

function VeiwOrder() {
    return(


<section>

<div className="sec-container" >
<Link to='/profile'> 
<h3 className="go_page">
<i class="fa-solid fa-arrow-left"></i> Go to profile page </h3>
   </Link>

<div className="anim_box1">

    <div className="anim_text1">
<div className="price1">
    <h2>Animating</h2> <p>Budget:<b>$70 000</b></p>
</div>
<p className="price1_text">
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Senectus in interdum et vulputate. Ornare sit eget sit facilisis leo nunc varius. Viverra orci, imperdiet volutpat aliquam a. Pellentesque sollicitudin fermentum imperdiet et, ac. Fringilla viverra semper amet mus eu sem. Cum erat at rhoncus nullam in gravida amet, eu gravida.
</p>
    </div>

        <div className="order">
            <div className="order_images">
        <img id='my_foto' src={ Order2 } alt="order-foto" />
        <img id='my_foto' src={ Order1 } alt="order-foto" />
        <img id='my_foto' src={ Order3 } alt="order-foto" />
            </div>

<div className="both">
    <div className="order_process">
<div className="process">
<h3>Process: </h3>
process function
<small>ends in 3 hours</small>
</div>
<div className="deadline">
<h3>Deadline: <big>12/10/2021</big> </h3>
deadline funtion
<small>ends in 3 hours</small>
</div>
</div>
<div className="edit"> 
<Link to='/'>

<button className="edit_button1">Edit</button>
</Link>
<Link to='/chat'>
<button className="edit_button2"> Go to chat</button>
</Link>
 </div>
 </div>
<button  className="cancel">Cancel the order</button>
    


</div>
</div>


<div className="anim_box2">
<div className="anim_text2">
<div className="price2">
    <h2>Animating</h2> <p>Budget:<b>$7000</b></p><Link to='/' className="cancel2">Cancel</Link>
</div>
<p className="price2_text">
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Senectus in interdum et vulputate. Ornare sit eget sit facilisis leo nunc varius. Viverra orci, imperdiet volutpat aliquam a. Pellentesque sollicitudin fermentum imperdiet et, ac. Fringilla viverra semper amet mus eu sem. Cum erat at rhoncus nullam in gravida amet, eu gravida.
</p>
    </div>

        <div className="order2">
            <div className="order_images2">
        <img id='my_foto2' src={ Order1 } alt="order-foto" />
        <img id='my_foto2' src={ Order2 } alt="order-foto" />
        <img id='my_foto2' src={ Order3 } alt="order-foto" />
        <img id='my_foto2' src={ Order1 } alt="order-foto" />
        <img id='my_foto2' src={ Order3 } alt="order-foto" />
        <img id='my_foto2' src={ Order2 } alt="order-foto" />
            </div>

<div className="both2">
    <div className="order_process2">
<div className="process2">
<h3>Process: </h3>
process function
<small>ends in 3 hours</small>
</div>
<div className="deadline2">
<h3>Deadline: <big>12/10/2021</big> </h3>
deadline funtion
<small>ends in 3 hours</small>
</div>
</div>
<div className="edit2" id='ed'> 
<Link to='/'>

<button className="edit_button3">Edit</button>
</Link>
<Link to='/chat'>
<button className="edit_button4"> Go to chat</button>
</Link>
 </div>
 </div>

    


</div>
</div>


</div>



</section>


    )
}









































export default VeiwOrder