import React from 'react'
import Header from "../components/Header"
import Section from '../components/Section'
import Footer from '../components/Footer'
import "../styles/home.css"

function Home() {
  return (
    <div id='rip'>
      <Header />
      <Section />
      <Footer />
    </div>
  )
}

export default Home