import React from 'react'
import Paid from '../components/Paid'
import Header2 from '../components/Header2'
import Footer from '../components/Footer'
function PaidPage() {
  return (
    <div>
      <Header2 />
      <Paid />
    <Footer />

    </div>
  )
}

export default PaidPage