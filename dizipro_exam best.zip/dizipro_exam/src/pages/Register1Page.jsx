import React from 'react'
import Register1 from '../components/Register1'

function Register1Page() {
  return (
    <div>
      <Register1 />
    </div>
  )
}

export default Register1Page