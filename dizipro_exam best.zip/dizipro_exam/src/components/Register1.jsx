import React from 'react'
import Logo from "../img/Rectangle (1).png"
import Donut from "../img/Torus.png"
import Cube from "../img/Cube.png"
import { Link } from 'react-router-dom'
import"../styles/Register1/registerr.css"
import Header from "./Header2"
function Register1() {
  return (
    <div className="reg_container">
      <Header />
        <div className="mr_container">
            <div className="head">
                
                <Link to='/' className='reg_img'><p><i class="fa-solid fa-arrow-left"></i>Back</p><img src={Logo} alt="reg_photo" id='log' /></Link>
                <select name="lang" id="lang">
                  <option value="ru">uz</option>
                  <option value="uz">ru</option>
                  </select>             
            </div>
            <div className="login">
                    <h1 className="login_text">Log in</h1>
                    <input className='reg_inp1' type="text" placeholder='Email'/>
                    <input className='reg_inp1' type="text" placeholder='Password'/>
                    <a href="" className="forget">Forgot your password?</a>
                    <Link to="/" className="reg_link">Register</Link>
                    <span>
                        <p className="help">Don`t have an account?</p>
                        <Link className='signup' to='/signup'>Sign up</Link>
                    </span>
                </div>
                <img src={Donut} alt="" className="donut" />
        <img src={Cube} alt="" className="cube" />
        </div>
        
    </div>
  )
}

export default Register1