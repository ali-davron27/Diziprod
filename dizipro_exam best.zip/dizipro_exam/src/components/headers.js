// const toggleButton = document.getElementByClassName('toggle_button')[0]
// const navbarLinks = document.getElementByClassName('#all-link')[0]

// toggleButton.addEventlistener('click',() =>{
//   navbarLinks.classList.toggle('active')
// })
