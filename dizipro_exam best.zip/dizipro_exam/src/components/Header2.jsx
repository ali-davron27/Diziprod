import React from 'react'
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Elips from "/home/kali/Desktop/react/dizipro_exam/src/img/Ellipse1.png"
import "../styles/Header2/header2.css"

function NavbarTwo() {

  const [ navbar, setNavbar ] = useState(false)


  const [ isMobil, setIsMobil ] = useState(false)

  const changeBackground = () =>{
    if(window.scrollY >= 80){
      setNavbar(true);
    }else{
      setNavbar(false)
    }
  }

  window.addEventListener("scroll", changeBackground)

  
  return (
    <nav className={navbar ? "nav2" : "navbar1" } >
          <div className={isMobil ? "container-mobile" : "container"}>
            <a className="nav_links2" href="#">
              <h1>dizipro</h1>
            </a>

            <ul className={isMobil ? "nav-list-mobile" : "nav_list2"}>

              <li className="nav_item2">
                <Link to="/" className="nav_link2">
                    Home
                </Link>
              </li>

              <li className="nav_item2">
                <Link to="/portfolio" className="nav_link2">
                    Portfolio
                </Link>
              </li>

              <li className="nav_item2">
                <Link to="/order" className="nav_link2">
                    Order a project
                </Link>
              </li>

              <li className="nav_item2">
                <Link to="/paid" className="nav_link2">
                    Paid courses
                </Link>
              </li>

              <li className="nav_item2">
                <Link to="/profile" className="nav_link2">
                    Profile
                </Link>
              </li>
            </ul>

          <div className="nav_box2">
            <Link to="/Settings" className='nav_icon2'>
              settings
            </Link>
            <button className="btn_nav2">Order now</button>


            <button className='mobile-menu-icon'
            onClick={() => setIsMobil(!isMobil)} >
              {isMobil ?<i id='closer' className='fas fa-times'></i> :
                        <i id='hamburger' className='fas fa-bars'></i>} 

            </button>

            <div className="img_nav_btn">
              <a href='#' className="img_nav_bt2">
                  <img src={Elips} alt="aylana" />
              </a>
            </div>
          </div>
        </div>  
      </nav>
  )
}

export default NavbarTwo