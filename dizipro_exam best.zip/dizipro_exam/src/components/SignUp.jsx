import React from 'react'
import Logo from "../img/Rectangle (1).png"
import Donut from "../img/Torus.png"
import Cube from "../img/Cube.png"
import { Link } from 'react-router-dom'
import "../styles/SignUp/signnn.css"
// import Head from "./Header2"
function SignUp() {
  return (
    <div className="sign_container">
        {/* <Head /> */}
        <div className="sm_container">
            <div className="head">                
                <Link className='reg_img1' to='/'><p><i class="fa-solid fa-arrow-left"></i>Go to home</p> <img src={Logo} alt="" />
                
                </Link>
                <select name="lang" id="sel">
                    <option value="eng">Eng</option>
<option value="uz">Uz</option>
<option value="ru">Ru</option>
<option value="ind">Ind</option>
                    </select>          
            </div>
            <div className="sign">
                <h1 className="sign_text">Sign up</h1>
                <input type="text" className="sign_inp" placeholder='Your name'/>
                <input type="email" className="sign_inp" placeholder='Email'/>
                <input type="password" className="sign_inp" placeholder='Password'/>

                <label>
                {/* <p className="gender">Gender</p> */}
                <select name="male" id="gendre">
                <option value="">Gendre</option>
                    <option value="m">MALE</option>
                    <option value="f">FEMALE</option>
                    <option value="-">-</option>
                    <option value="o">Other</option>
                </select>
                </label>
                <select id='place'>
                    <option value="" >Country</option>
                    <option value="uz">Russia</option>
                    <option value="uz">USA</option>
                    <option value="uz">Uzbekistan</option>
                    <option value="uz">Other</option>
                </select>
                <p className="sign_text2">
                    By clicking Create account, I agree that I have read and accepted the <a href="#">Terms of Use</a> and <a href="#">Privacy policy</a>
                </p>
                <Link to='/' className="sign_link">Next</Link>
                <p className="sign_text3">Already have an account? <Link to='/register'>Log in</Link></p>
            </div>
            <img src={Donut} alt="" className="donut" />
        <img src={Cube} alt="" className="cube" />
        </div>

        
    </div>
  )
}

export default SignUp