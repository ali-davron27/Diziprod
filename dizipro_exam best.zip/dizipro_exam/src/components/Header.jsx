import React from 'react'
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "../styles/Header/header1.css"

function Navbar() {

  const [ navbar, setNavbar ] = useState(false)
  const [ isMobil, setIsMobil ] = useState(false)



  const changeBackground = () =>{
    if(window.scrollY >= 80){
      setNavbar(true);
    }else{
      setNavbar(false)
    }
  }

  window.addEventListener("scroll", changeBackground)
  return (
    <nav className={navbar ? "nav" : "navbar" } >
          <div className={isMobil ? "container-mobile" : "containerh"}>

            <Link className="nav_links" to="/">
              <h1>dizipro</h1>
            </Link>

            <ul className={isMobil ? "nav-list-mobile" : "nav_list"}>


              <li className="nav_item">
                <Link to="/" className="nav_link">
                    Home
                </Link>
              </li>

              <li className="nav_item">
                <Link to="/portfolio" className="nav_link">
                    Portfolio
                </Link>
              </li>

              <li className="nav_item">
                <Link to="/order" className="nav_link">
                    Order  project
                </Link>
              </li>

              <li className="nav_item">
                <Link to="/paid" className="nav_link">
                    Paid courses
                </Link>
              </li>

              <li className="nav_item">
                <Link to="/profile" className="nav_link">
                    Profile
                </Link>
              </li>
            </ul>

          <div className="nav_box">
            <select className='nav_icon'  name="select" id="sel">
<option value="eng"><p>en</p> </option>
<option value="rus">rus</option>
<option value="uzb">uz</option>
            </select>
            
            <button className="btn_nav active">Order now</button>
           
            <Link  to="/register">
              <button className="btn_nav" id='reg'>Register</button>
            </Link>

            <button className='mobile-menu-icon'
            onClick={() => setIsMobil(!isMobil)} >
              {isMobil ?<i id='ram' ><b>x</b> </i> :
                        <i id='ham' className='fas fa-bars'></i>} 

            </button>
          </div>
        </div>  
      </nav>
  )
}

export default Navbar