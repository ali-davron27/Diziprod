import React from 'react'
import "../styles/Footer/footer1.css"
import { Link } from 'react-router-dom'

function Footer() {
  return (
  


<footer id="ffff"> 
  <div class="containerf">
    <div class="footer_box">
      <div class="footer_header">
        <h1>Biz bilan hamkor bo’ling</h1>
        <p>Biz sifatli va ajoyib modellarni sizga taqdim qilamiz</p>
        <button>Order a project</button>
        </div>
        <div class="footer_foter">
          <div class="footer_left">
            <ul class="footer_list">
              <li class="footer_items">
                <Link class="footer_links" to="/">
                  <h1>dizipro</h1></Link >
                  </li>
                  <li class="footer_item">
                    
                    <a class="footer_link" href="/">Home</a>
                    </li>
                    <li class="footer_item"><Link class="footer_link" to="/portfolio">Portfolio</Link>
                    </li>
                    <li class="footer_item">
                      <Link class="footer_link" to="/order">Order a project</Link>
                      </li>
                      <li class="footer_item">
                        <Link class="footer_link" to="/paid">Paid courses</Link>
                        </li>
                        </ul>
                        </div>
                        <div class="footer_right">
                          <a href="https://instagram.con" class="instagram">
                            <i class="fa-brands fa-instagram">
                              </i>
                              </a>
                              <a href="https://t.me" class="telegram">
                                <i class="fa-brands fa-telegram">
                                  </i>
                                  </a>
                                  <a href="https://facebook.com" class="facebook"><i class="fa-brands fa-facebook">
                                    </i>
                                    </a>
                                    </div>
                                    </div>
                                    </div>
                                    </div>
                                    </footer>
)
}

export default Footer