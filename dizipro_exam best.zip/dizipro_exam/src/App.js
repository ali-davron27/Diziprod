import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Home from "./pages/Home";
import PortfolioPage from "./pages/PortfolioPage";
import OrderPage from "./pages/OrderPage";
import CheckedPage from './pages/CheckedPage'
import PaidPage from './pages/PaidPage'
import PaymentPage from './pages/PaymentPage'
import LoginPage from './pages/LoginPage'
import Register1 from './pages/Register1Page'
import Signup from './pages/SignupPage'
import ChatPage from './pages/ChatPage'
import Profile from './components/Profile'
import View from './pages/View oreder/VeiwOrder'
function App() {
  return (
    <BrowserRouter>
      <Switch>
      <Route exact path='/' component={Home}/>
      <Route path='/portfolio' component={PortfolioPage}/>
      <Route path='/order' component={OrderPage}/>
      <Route path='/paid' component={PaidPage}/>
      <Route path='/payment' component={PaymentPage}/>
      <Route path='/login' component={LoginPage}/>
      <Route path='/checked' component={CheckedPage}/>
      <Route path='/register' component={Register1}/>
      <Route path='/signup' component={Signup}/>
      <Route path='/chat' component={ChatPage}/>
      <Route path='/profile' component={Profile}/>
      <Route path='/view' component={View}/>
    </Switch>
    </BrowserRouter>
  );
}

export default App;
